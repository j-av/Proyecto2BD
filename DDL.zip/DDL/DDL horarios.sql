-- public.empleados foreign keys

ALTER TABLE public.empleados ADD CONSTRAINT codigo_puesto FOREIGN KEY (codigopuesto) REFERENCES public.puestos(codigopuesto);
ALTER TABLE public.empleados ADD CONSTRAINT codigo_ubicacion FOREIGN KEY (codigocu) REFERENCES public.sucursales(codigoubiacion);

-- public.horarios definition

-- Drop table

-- DROP TABLE public.horarios;

CREATE TABLE public.horarios (
	tipohorario varchar(50) NULL,
	idhorario int4 NULL
);

