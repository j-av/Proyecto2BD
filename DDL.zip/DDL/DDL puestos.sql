-- public.puestos definition

-- Drop table

-- DROP TABLE public.puestos;

CREATE TABLE public.puestos (
	codigopuesto int4 NOT NULL GENERATED ALWAYS AS IDENTITY,
	puesto varchar NOT NULL,
	CONSTRAINT puestos_pkey PRIMARY KEY (codigopuesto)
);