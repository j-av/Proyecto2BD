-- public.imagen2 definition

-- Drop table

-- DROP TABLE public.imagen2;

CREATE TABLE public.imagen2 (
	imagen bytea NULL
);