-- public."control" definition

-- Drop table

-- DROP TABLE public."control";

CREATE TABLE public."control" (
	cuentapago int4 NULL,
	descimpuesto float4 NULL,
	bonos float4 NULL,
	horasextra int4 NULL,
	pagohorasextra float4 NULL,
	vacaciones bool NULL,
	transporte bool NULL,
	refaccion bool NULL,
	codigocu int4 NOT NULL GENERATED ALWAYS AS IDENTITY
);