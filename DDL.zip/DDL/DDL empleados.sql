-- public.empleados definition

-- Drop table

-- DROP TABLE public.empleados;

CREATE TABLE public.empleados (
	nombre varchar(50) NULL,
	apellido varchar(50) NULL,
	nacimiento date NULL,
	sexo bpchar(1) NULL,
	telefono varchar(50) NULL,
	correo varchar(300) NULL,
	nacionalidad varchar(50) NULL,
	ciudad varchar(150) NULL,
	direccion varchar(500) NULL,
	codigopuesto int4 NOT NULL,
	salario float4 NULL,
	fechacontratacion date NULL,
	codigocu int4 NULL,
	activo bool NULL,
	codigo int4 NOT NULL GENERATED ALWAYS AS IDENTITY,
	imagen bytea NULL,
	idhorario int4 NULL,
	CONSTRAINT empleados_pkey PRIMARY KEY (codigo)
);

