-- public.sucursales definition

-- Drop table

-- DROP TABLE public.sucursales;

CREATE TABLE public.sucursales (
	codigoubiacion int4 NOT NULL GENERATED ALWAYS AS IDENTITY,
	paisubicacion varchar NULL,
	direccionsucursal varchar NULL,
	telefonosucursal varchar NULL,
	correosucursal varchar(150) NOT NULL,
	nombresucursal varchar NULL,
	CONSTRAINT sucursales_pkey PRIMARY KEY (codigoubiacion)
);